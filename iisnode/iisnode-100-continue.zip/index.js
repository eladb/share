var http = require('http');

http.createServer(function(req, res) {
  res.end('hey');
}).listen(process.env.PORT);

